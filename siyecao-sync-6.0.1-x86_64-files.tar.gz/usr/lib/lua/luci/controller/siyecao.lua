-- 四叶草TV 同步服务 LuCI 管理页（全部管理功能都在这里，1986 端口只提供 API）
module("luci.controller.siyecao", package.seeall)

local VERSION = "6.0"

local sys  = require "luci.sys"
local http = require "luci.http"
local disp = require "luci.dispatcher"

local DEFAULT_DIR = "/mnt/sda3/siyecao-sync/data"

function index()
	entry({"admin", "services", "siyecao"}, call("action_index"), _("四叶草同步"), 62)
end

local function run(cmd)
	sys.call(cmd .. " >/dev/null 2>&1")
end

local function trim(s)
	return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

local function esc(s)
	return tostring(s == nil and "" or s)
		:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")
		:gsub('"', "&quot;"):gsub("'", "&#39;")
end

local function urlencode(s)
	return (tostring(s):gsub("[^%w%-%._~]", function(c)
		return string.format("%%%02X", string.byte(c))
	end))
end

local function current(field, default)
	local uci = require "luci.model.uci".cursor()
	return uci:get("siyecao-sync", "@siyecao[0]", field) or default
end

local function setopt(field, value)
	local uci = require "luci.model.uci".cursor()
	uci:set("siyecao-sync", "@siyecao[0]", field, value)
	uci:commit("siyecao-sync")
end

-- 本机调用 Go 服务（优先 busybox wget，缺失时回退 curl）
local function http_get(port, path, timeout)
	local url = "http://127.0.0.1:" .. port .. path
	local out = sys.exec("wget -qO- --timeout=" .. timeout .. " " .. url .. " 2>/dev/null")
	if not out or out == "" then
		out = sys.exec("curl -s --max-time " .. timeout .. " " .. url .. " 2>/dev/null")
	end
	return out or ""
end

local function http_post(port, path, data, timeout)
	local url = "http://127.0.0.1:" .. port .. path
	local out = sys.exec("wget -qO- --timeout=" .. timeout .. " --post-data='" .. data ..
		"' " .. url .. " 2>/dev/null")
	if not out or out == "" then
		out = sys.exec("curl -s --max-time " .. timeout .. " -d '" .. data .. "' " .. url .. " 2>/dev/null")
	end
	return out or ""
end

-- 读取 Go 服务暴露给本机的纯文本摘要（TSV），避免在 Lua 里解析 JSON
local function read_summary(port)
	local out = http_get(port, "/api/summary", 2)
	local info = { users_list = {}, api_ok = false }
	if out == "" then
		return info
	end
	for line in out:gmatch("[^\n]+") do
		local parts = {}
		for f in (line .. "\t"):gmatch("(.-)\t") do
			parts[#parts + 1] = f
		end
		local k = parts[1]
		if k == "user" then
			info.users_list[#info.users_list + 1] = {
				no      = tonumber(parts[2]) or 0,
				name    = parts[3] or "",
				created = tonumber(parts[4]) or 0,
				records = tonumber(parts[5]) or 0,
			}
		elseif k then
			info[k] = parts[2]
		end
	end
	info.api_ok = info.version ~= nil
	return info
end

-- 数据目录是否落在真实磁盘上（rootfs / overlay 表示写在内置 flash，重启可能丢）
local function disk_status(dir)
	if sys.call("[ -d '" .. dir .. "' ]") ~= 0 then
		return false, ""
	end
	local dev = trim(sys.exec("df -P '" .. dir .. "' 2>/dev/null | tail -1 | awk '{print $1}'"))
	if dev == "" then
		return false, ""
	end
	if dev == "rootfs" or dev == "/dev/root" or dev:match("^overlay") then
		return false, dev
	end
	return true, dev
end

local function fmt_size(bytes)
	bytes = tonumber(bytes) or 0
	if bytes >= 1048576 then
		return string.format("%.1f MB", bytes / 1048576)
	elseif bytes >= 1024 then
		return string.format("%.1f KB", bytes / 1024)
	end
	return bytes .. " B"
end

local function fmt_time(ts)
	ts = tonumber(ts) or 0
	if ts <= 0 then
		return "-"
	end
	return os.date("%Y-%m-%d %H:%M", math.floor(ts / 1000))
end

local function fmt_uptime(sec)
	sec = tonumber(sec) or 0
	local d, h, m = math.floor(sec / 86400), math.floor(sec % 86400 / 3600), math.floor(sec % 3600 / 60)
	if d > 0 then
		return string.format("%d 天 %d 小时", d, h)
	elseif h > 0 then
		return string.format("%d 小时 %d 分", h, m)
	end
	return string.format("%d 分", m)
end

local CSS = [[
body{margin:0;padding:20px;background:#f4f5f7;color:#222;
     font:14px/1.6 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif}
h2{margin:0 0 16px;font-size:18px}
h2 small{color:#999;font-size:12px;font-weight:400}
.card{background:#fff;border-radius:6px;padding:16px 18px;margin-bottom:14px;
      box-shadow:0 1px 3px rgba(0,0,0,.08)}
.card h3{margin:0 0 12px;font-size:14px;color:#555;font-weight:600}
table{width:100%;border-collapse:collapse}
td,th{padding:6px 8px;vertical-align:top;text-align:left;border-bottom:1px solid #f0f1f3}
td.k{width:170px;color:#666;border-bottom:0;padding-left:0}
th{color:#666;font-weight:600;font-size:13px;background:#fafbfc}
code{background:#f0f1f2;padding:1px 5px;border-radius:3px;font-size:13px}
input[type=text]{padding:5px 8px;border:1px solid #ccd;border-radius:4px;font-size:13px}
.btn{padding:6px 16px;border:0;border-radius:4px;cursor:pointer;font-size:13px;
     background:#2a7ae2;color:#fff}
.btn:disabled{background:#c5c8cc;cursor:default}
.btn.gray{background:#78808c}
.btn.red{background:#d9534f}
.btn.green{background:#2e9e4f}
.inline{display:inline-block;margin:0 8px 8px 0}
.alert{padding:10px 14px;border-radius:4px;margin-bottom:14px}
.alert.err{background:#fdecea;color:#a12622;border:1px solid #f5c2c0}
.alert.ok{background:#eaf7ed;color:#1e6b33;border:1px solid #bfe3c8}
.hint{color:#888;font-size:12px;margin-top:4px}
.warn{color:#c62828}
.ok{color:#2e7d32}
.sep{margin-top:12px;padding-top:12px;border-top:1px solid #eee}
.back{font-size:13px;color:#2a7ae2;text-decoration:none}
]]

local function btn(action, label, cls, disabled)
	return string.format(
		'<form method="post" class="inline">' ..
		'<input type="hidden" name="action" value="%s">' ..
		'<input type="submit" class="btn %s" value="%s"%s></form>',
		esc(action), cls or "", esc(label), disabled and " disabled" or "")
end

local function render_page(c)
	local h = {}

	h[#h + 1] = '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
	h[#h + 1] = '<meta name="viewport" content="width=device-width,initial-scale=1">'
	h[#h + 1] = '<title>四叶草同步服务</title><style>' .. CSS .. '</style></head><body>'
	h[#h + 1] = '<a class="back" href="' .. esc(c.admin_url) .. '">&larr; 返回 LuCI</a>'
	h[#h + 1] = '<h2 style="margin-top:10px">四叶草同步服务 <small>v' .. esc(c.version) .. '</small></h2>'

	if c.err then
		h[#h + 1] = '<div class="alert err">' .. esc(c.err) .. '</div>'
	elseif c.notice then
		h[#h + 1] = '<div class="alert ok">' .. esc(c.notice) .. '</div>'
	end

	-- 运行状态
	h[#h + 1] = '<div class="card"><h3>运行状态</h3><table>'
	h[#h + 1] = '<tr><td class="k">服务状态</td><td>' ..
		(c.running and '<b class="ok">&bull; 运行中</b>' or '<b class="warn">&bull; 已停止</b>') .. '</td></tr>'
	h[#h + 1] = '<tr><td class="k">开机自启</td><td>' ..
		(c.enabled and '<span class="ok">已启用</span>' or '<span class="warn">未启用</span>') .. '</td></tr>'

	h[#h + 1] = '<tr><td class="k">客户端访问</td><td>' ..
		(c.app_enabled and '<b class="ok">&bull; 正常开放</b>' or '<b class="warn">&bull; 已紧急关停</b>')
	if c.app_lock_conflict then
		h[#h + 1] = '<div class="warn hint">配置文件里 app_enabled 仍为 0，重启服务后会继续保持关停。</div>'
	end
	h[#h + 1] = '</td></tr>'

	h[#h + 1] = '<tr><td class="k">监听端口</td><td>' .. esc(c.port) ..
		' <span class="hint">该端口只提供 API，没有网页</span></td></tr>'
	h[#h + 1] = '<tr><td class="k">数据目录</td><td><code>' .. esc(c.dir) .. '</code>'
	if c.running and not c.real_disk then
		h[#h + 1] = '<div class="warn hint">该目录不在独立磁盘上（设备：' ..
			esc(c.disk_dev ~= "" and c.disk_dev or "未知") ..
			'），数据写在内置 flash，重启或刷固件后可能丢失。</div>'
	end
	h[#h + 1] = '</td></tr>'

	if c.running and c.api_ok then
		h[#h + 1] = '<tr><td class="k">运行时长</td><td>' .. esc(c.uptime) .. '</td></tr>'
		h[#h + 1] = '<tr><td class="k">数据统计</td><td>' .. esc(c.user_count) .. ' 个用户 / ' ..
			esc(c.record_count) .. ' 条记录 / 占用 ' .. esc(c.data_size) .. '</td></tr>'
	end
	h[#h + 1] = '</table></div>'

	-- 操作
	h[#h + 1] = '<div class="card"><h3>操作</h3>'
	h[#h + 1] = btn("start", "启动", "", c.running)
	h[#h + 1] = btn("stop", "停止", "red", not c.running)
	h[#h + 1] = btn("restart", "重启", "gray", not c.running)
	if c.enabled then
		h[#h + 1] = btn("disable", "关闭自启", "gray", false)
	else
		h[#h + 1] = btn("enable", "开启自启", "gray", false)
	end
	h[#h + 1] = '<div class="sep">'
	if c.app_enabled then
		h[#h + 1] = btn("disable_app", "紧急关停所有客户端", "red", false)
	else
		h[#h + 1] = btn("enable_app", "恢复客户端访问", "green", false)
	end
	h[#h + 1] = '<span class="hint">关停后客户端立即无法注册/登录/同步；恢复后需重启客户端 App 解除锁定。</span>'
	h[#h + 1] = '</div></div>'

	-- 用户管理
	h[#h + 1] = '<div class="card"><h3>用户管理'
	if c.running and c.api_ok then
		h[#h + 1] = '（' .. esc(c.user_count) .. '）'
	end
	h[#h + 1] = '</h3>'

	if not c.running then
		h[#h + 1] = '<div class="hint">服务未运行，无法读取用户列表。</div>'
	elseif not c.api_ok then
		h[#h + 1] = '<div class="hint">无法连接本机 API，请检查端口和数据目录是否正确。</div>'
	elseif #c.users == 0 then
		h[#h + 1] = '<div class="hint">还没有任何用户注册。</div>'
	else
		h[#h + 1] = '<table><tr><th>编号</th><th>用户名</th><th>注册时间</th><th>记录数</th><th>操作</th></tr>'
		for _, u in ipairs(c.users) do
			h[#h + 1] = '<tr><td>' .. esc(u.no) .. '</td><td>' .. esc(u.name) .. '</td><td>' ..
				esc(fmt_time(u.created)) .. '</td><td>' .. esc(u.records) .. '</td><td>' ..
				'<form method="post" onsubmit="return confirm(\'确定删除该用户及其全部播放记录？此操作不可恢复。\')">' ..
				'<input type="hidden" name="action" value="deluser">' ..
				'<input type="hidden" name="name" value="' .. esc(u.name) .. '">' ..
				'<input type="submit" class="btn red" value="删除"></form></td></tr>'
		end
		h[#h + 1] = '</table>'
	end
	h[#h + 1] = '</div>'

	-- 设置
	h[#h + 1] = '<form method="post"><input type="hidden" name="action" value="save">'
	h[#h + 1] = '<div class="card"><h3>设置</h3><table>'
	h[#h + 1] = '<tr><td class="k">监听端口</td><td>' ..
		'<input type="text" name="port" value="' .. esc(c.port) .. '" style="width:120px">' ..
		'<div class="hint">客户端连接使用的端口，默认 1986</div></td></tr>'
	h[#h + 1] = '<tr><td class="k">数据保存路径</td><td>' ..
		'<input type="text" name="data_dir" value="' .. esc(c.dir) .. '" style="width:420px;max-width:100%">' ..
		'<div class="hint">绝对路径，记录会写入该目录下的 <code>sync.json</code>，目录不存在时启动自动创建。<br>' ..
		'检测到的挂载点：<code>' .. esc(c.mounts ~= "" and c.mounts or "无") .. '</code>，' ..
		'建议放在独立磁盘上，例如 <code>' .. esc(c.default_dir) .. '</code>。<br>' ..
		'修改路径不会迁移旧数据，原目录里的记录需要手动拷过去。</div></td></tr>'
	h[#h + 1] = '</table><div class="sep"><input type="submit" class="btn" value="保存并重启"></div></div></form>'

	-- 客户端配置
	h[#h + 1] = '<div class="card"><h3>客户端配置</h3><table>' ..
		'<tr><td class="k">同步服务器地址</td><td><code>http://' .. esc(c.host) .. ':' .. esc(c.port) .. '</code>' ..
		'<div class="hint">四叶草 App → 设置 → 自定义同步服务器，填这个地址</div></td></tr></table></div>'

	h[#h + 1] = '</body></html>'
	return table.concat(h)
end

-- 切换客户端访问开关：优先让服务自己写标记文件，避免 LuCI 与服务的数据目录不一致
-- 返回 true 表示切换成功
local function set_app_enabled(port, dir, enabled)
	local body = enabled and '{"enabled":true}' or '{"enabled":false}'
	local resp = http_post(port, "/api/killswitch", body, 3)
	if resp:find('"ok"%s*:%s*true') then
		return true
	end
	-- 服务未运行或接口不可用时，退回直接操作标记文件
	local disabled_file = dir .. "/.disabled"
	if enabled then
		return sys.call("rm -f '" .. disabled_file .. "'") == 0
	end
	if sys.call("mkdir -p '" .. dir .. "' && touch '" .. disabled_file .. "'") ~= 0 then
		return false
	end
	return true
end

function action_index()
	local action = http.formvalue("action")
	local err, notice

	local port = current("port", "1986")
	local dir  = current("data_dir", DEFAULT_DIR)
	local disabled_file = dir .. "/.disabled"

	if action == "save" then
		local new_port = http.formvalue("port")
		local new_dir  = http.formvalue("data_dir")

		if not new_port or not new_port:match("^%d+$")
			or tonumber(new_port) < 1 or tonumber(new_port) > 65535 then
			err = "端口必须是 1-65535 之间的数字"
		elseif not new_dir or not new_dir:match("^/[%w%-%._/]+$") then
			err = "数据目录必须是绝对路径，且只能包含字母、数字、- _ . /"
		else
			setopt("port", new_port)
			setopt("data_dir", new_dir)
			run("/etc/init.d/siyecao-sync restart")
			port, dir = new_port, new_dir
			disabled_file = dir .. "/.disabled"
			notice = "设置已保存，服务已重启"
		end
	elseif action == "disable_app" then
		if not set_app_enabled(port, dir, false) then
			err = "关停失败：服务未运行且无法写入数据目录"
		end
		setopt("app_enabled", "0")
		if err then
			-- 失败时留在本页显示原因
			notice = nil
		else
			http.redirect(disp.build_url("admin", "services", "siyecao"))
			return
		end
	elseif action == "enable_app" then
		if not set_app_enabled(port, dir, true) then
			err = "恢复失败：服务未运行且无法删除数据目录里的关停标记"
		end
		setopt("app_enabled", "1")
		if err then
			notice = nil
		else
			http.redirect(disp.build_url("admin", "services", "siyecao"))
			return
		end
	elseif action == "deluser" then
		local name = http.formvalue("name")
		if not name or name == "" then
			err = "缺少用户名"
		else
			local resp = http_post(port, "/api/users/delete", "name=" .. urlencode(name), 3)
			if resp:find('"ok"%s*:%s*true') then
				notice = "已删除用户 " .. name .. "（记录和登录令牌一并清除）"
			else
				err = "删除失败，请确认服务正在运行"
			end
		end
	elseif action then
		if action == "start" then
			run("/etc/init.d/siyecao-sync start")
		elseif action == "stop" then
			run("/etc/init.d/siyecao-sync stop")
		elseif action == "restart" then
			run("/etc/init.d/siyecao-sync restart")
		elseif action == "enable" then
			run("/etc/init.d/siyecao-sync enable")
		elseif action == "disable" then
			run("/etc/init.d/siyecao-sync disable")
		end
		http.redirect(disp.build_url("admin", "services", "siyecao"))
		return
	end

	local running = (sys.call("pidof siyecao-sync >/dev/null 2>&1") == 0)
	local enabled = (sys.call("[ -f /etc/rc.d/S99siyecao-sync ]") == 0)

	-- 关停状态由数据目录下的 .disabled 文件控制（运行时动态切换，无需重启）
	local summary = running and read_summary(port) or { users_list = {}, api_ok = false }

	-- 以服务自报的状态为准；服务没起来时才回退看标记文件
	local app_enabled
	if summary.api_ok and summary.enabled then
		app_enabled = (summary.enabled == "1")
	else
		app_enabled = (sys.call("[ -f '" .. disabled_file .. "' ]") ~= 0)
	end
	local app_lock_conflict = (not app_enabled) and (current("app_enabled", "1") ~= "0")

	local real_disk, dev = disk_status(dir)
	local mounts = trim(sys.exec("ls -d /mnt/*/ 2>/dev/null | tr '\\n' ' '"))

	local host = http.getenv("HTTP_HOST") or http.getenv("SERVER_ADDR") or "192.168.1.1"
	host = host:gsub(":%d+$", "")

	local page = render_page({
		version    = VERSION,
		port       = port,
		dir        = dir,
		host       = host,
		running    = running,
		enabled    = enabled,
		app_enabled = app_enabled,
		app_lock_conflict = app_lock_conflict,
		api_ok     = summary.api_ok,
		uptime     = fmt_uptime(summary.uptime),
		user_count = summary.users or "0",
		record_count = summary.records or "0",
		data_size  = fmt_size(summary.size),
		users      = summary.users_list,
		real_disk  = real_disk,
		disk_dev   = dev,
		mounts     = mounts,
		default_dir = DEFAULT_DIR,
		admin_url  = disp.build_url("admin", "services"),
		err        = err,
		notice     = notice,
	})

	http.prepare_content("text/html; charset=utf-8")
	http.write(page)
end
